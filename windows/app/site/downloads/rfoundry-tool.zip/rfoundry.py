# SPDX-License-Identifier: MIT
# Copyright (c) 2026 The RadioFoundry Authors
"""rfoundry from this folder, without installing it: python3 rfoundry.py --help (README.txt)."""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
# this file's own folder would make "import rfoundry" load this script, not the package
sys.path[:] = [p for p in sys.path if os.path.abspath(p or os.curdir) != HERE]
sys.path.insert(0, os.path.join(HERE, "tools", "rfoundry"))

from rfoundry.cli import main  # noqa: E402

if __name__ == "__main__":
    sys.exit(main())
